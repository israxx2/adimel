import { SpinnerOptions } from '../types/interfaces';
export declare function makeSpinner({ fillColor }: SpinnerOptions): HTMLElement;
